/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scientific.calculator;

/**
 *
 * @author 23769
 */
 import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ScientificCalculator extends JFrame {

    private JTextField displayField;

    public ScientificCalculator() {
        super("Scientific Calculator");

        displayField = new JTextField(15);
        displayField.setEditable(false);

        
        JButton[] numberButtons = new JButton[10];
        for (int i = 0; i < numberButtons.length; i++) {
            final int number = i;
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener((ActionEvent e) -> {
                displayField.setText(displayField.getText() + number);
            });
        }

        JButton addButton = new JButton("+");
        addButton.addActionListener(new OperationListener());
        JButton subtractButton = new JButton("-");
        subtractButton.addActionListener(new OperationListener());
        JButton multiplyButton = new JButton("*");
        multiplyButton.addActionListener(new OperationListener());
        JButton divideButton = new JButton("/");
        divideButton.addActionListener(new OperationListener());
        JButton equalsButton = new JButton("=");
        equalsButton.addActionListener(new OperationListener());

         
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 4));
        buttonPanel.add(numberButtons[7]);
        buttonPanel.add(numberButtons[8]);
        buttonPanel.add(numberButtons[9]);
        buttonPanel.add(addButton);
        buttonPanel.add(numberButtons[4]);
        buttonPanel.add(numberButtons[5]);
        buttonPanel.add(numberButtons[6]);
        buttonPanel.add(subtractButton);
        buttonPanel.add(numberButtons[1]);
        buttonPanel.add(numberButtons[2]);
        buttonPanel.add(numberButtons[3]);
        buttonPanel.add(multiplyButton);
        buttonPanel.add(numberButtons[0]);
        buttonPanel.add(equalsButton);
        buttonPanel.add(divideButton);

       
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());

        
        cp.add(displayField, BorderLayout.NORTH);
        cp.add(buttonPanel, BorderLayout.CENTER);

         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 300);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    
    class OperationListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

             
            Double.valueOf(displayField.getText());

            
            displayField.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ScientificCalculator().setVisible(true);
        });
    }
}